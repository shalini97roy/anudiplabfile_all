package org.anudip.lab.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.anudip.concurrent.ContractEmployee;
import org.junit.jupiter.api.Test;

class ContractEmployeeTest {

	 @Test
	    public void testCalculateTax() {
	        ContractEmployee contractEmployee = new ContractEmployee("Lillian Williams", "Store", 3, 750000.00);
	        contractEmployee.calculateTax();

	        double expectedTax = 750000.00 * 0.10; // 10% of the contract amount
	        assertEquals(expectedTax, contractEmployee.getTax(), 0.001);
	    }
	@Test
 public void testToString() {
     ContractEmployee contractEmployee = new ContractEmployee("Lillian Williams", "Store", 3, 750000.00);
     contractEmployee.calculateTax();

     String expected = "C1001      Lillian Williams     Store          3          750000.00  25000.00  ";
     String actual = contractEmployee.toString();

     assertEquals(normalizeSpace(expected), normalizeSpace(actual));
 }
	private Short normalizeSpace(String expected) {
		// TODO Auto-generated method stub
		return null;	}

}
