package org.anudip.lab.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.anudip.concurrent.PermanentEmployee;
import org.junit.jupiter.api.Test;

class PermanentEmployeeTest {

	 @Test
	    public void testCalculateTax() {
	        PermanentEmployee permanentEmployee = new PermanentEmployee("Becky Robins", "Admin", 27500.00);
	        permanentEmployee.calculateTax();

	        assertEquals(33000.00, permanentEmployee.getTax(), 0.001);
	    }

	    @Test
	    public void testToString() {
	        PermanentEmployee permanentEmployee = new PermanentEmployee("Becky Robins", "Admin", 27500.00);
	        permanentEmployee.calculateTax();

	        String expected = "P1001      Becky Robins         Admin          27500.00   4125.00    33000.00";
	        String actual = permanentEmployee.toString();

	        assertEquals(normalizeSpace(expected), normalizeSpace(actual));
	    }
	    // Add more test methods as needed

		private Short normalizeSpace(String expected) {
			// TODO Auto-generated method stub
			return null;	
			}

}
