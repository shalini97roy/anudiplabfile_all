/*package org.anudip.lab.testing;
import static org.junit.Assert.assertEquals;

import org.anudip.concurrent.ContractEmployee;
import org.anudip.concurrent.Employee;
import org.anudip.concurrent.EmployeeMain;
import org.anudip.concurrent.PermanentEmployee;
import org.junit.Test;
import java.util.List;


class EmployeeMainTest {

	@Test
	public void testPermanentEmployeeTaxCalculation() {
        PermanentEmployee permanentEmployee = new PermanentEmployee("John Doe", "Finance", 50000.00);
        permanentEmployee.calculateTax();
        assertEquals(60000.00 * 0.10, permanentEmployee.getTax(), 0.01);
    }

    @Test
    public void testContractEmployeeTaxCalculation() {
        ContractEmployee contractEmployee = new ContractEmployee("Jane Smith", "Sales", 3, 800000.00);
        contractEmployee.calculateTax();
        assertEquals(800000.00 * 0.10, contractEmployee.getTax(), 0.01);
    }

    @Test
    public void testPermanentEmployeeIdGeneration() {
        PermanentEmployee permanentEmployee1 = new PermanentEmployee("John Doe", "Finance", 50000.00);
        PermanentEmployee permanentEmployee2 = new PermanentEmployee("Jane Smith", "Sales", 60000.00);

        assertEquals("P1001", permanentEmployee1.getEmployeeId());
        assertEquals("P1002", permanentEmployee2.getEmployeeId());
    }

    @Test
    public void testContractEmployeeIdGeneration() {
        ContractEmployee contractEmployee1 = new ContractEmployee("Alice Johnson", "Admin", 2, 700000.00);
        ContractEmployee contractEmployee2 = new ContractEmployee("Bob Brown", "IT", 4, 900000.00);

        assertEquals("C1001", contractEmployee1.getEmployeeId());
        assertEquals("C1002", contractEmployee2.getEmployeeId());
    }

    @Test
    public void testEmployeeSorting() {
        EmployeeMain employeeMain = new EmployeeMain();
        employeeMain.addPermanentEmployee(new PermanentEmployee("John Doe", "Finance", 50000.00));
        employeeMain.addPermanentEmployee(new PermanentEmployee("Jane Smith", "Sales", 60000.00));
        employeeMain.addContractEmployee(new ContractEmployee("Alice Johnson", "Admin", 2, 700000.00));
        employeeMain.addContractEmployee(new ContractEmployee("Bob Brown", "IT", 4, 900000.00));

        List<Employee> sortedPermanentEmployees = employeeMain.getSortedPermanentEmployees();
        List<Employee> sortedContractEmployees = employeeMain.getSortedContractEmployees();

        assertEquals("P1001", sortedPermanentEmployees.get(0).getEmployeeId());
        assertEquals("P1002", sortedPermanentEmployees.get(1).getEmployeeId());
        assertEquals("C1002", sortedContractEmployees.get(0).getEmployeeId());
        assertEquals("C1001", sortedContractEmployees.get(1).getEmployeeId());

	}

}*/
