package org.anudip.lab;
class BillService {
    public static String billCalculation(Consumer consumer) {
        int unitConsumed = consumer.getUnitConsumed();
        double finalPayment = 0.0;

        if (unitConsumed <= 200) {
            finalPayment = 300.0;
        } else if (unitConsumed <= 500) {
            finalPayment = 300.0 + (unitConsumed - 200) * 1.25;
        } else if (unitConsumed <= 1000) {
            finalPayment = 300.0 + 300.0 + (unitConsumed - 500) * 1.00;
        } else {
            finalPayment = 300.0 + 300.0 + 500.0 + (unitConsumed - 1000) * 0.75;
        }
        return String.format("%.2f", finalPayment);
    }
}
