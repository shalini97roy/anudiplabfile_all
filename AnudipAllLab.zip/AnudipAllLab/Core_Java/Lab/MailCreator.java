package org.anudip.Lab;
import java.util.Scanner;
public class MailCreator 
{
	 static String createMailAccount(String studentName) 
	 {
	        // Convert the student name to lowercase
	        String lowercaseName = studentName.toLowerCase();
	        // Replace spaces with dots
	        String formattedName = lowercaseName.replace(" ", ".");
	        // Append the domain and return the email address
	        return formattedName + "@tsr.edu";
	   }
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        // Accept the student name
	        System.out.print("Enter the student name: ");
	        String studentName = scanner.nextLine();
	        // Create the mail account
	        String mailAccount = createMailAccount(studentName);
	        // Display the student's mail account
	        System.out.println("Student's mail account: " + mailAccount);
	   }//end of method
}//end of class

