package org.anudip.lab;
class Consumer {
    private String id;
    private String name;
    private Integer unitConsumed;
    private String finalPayment;
    public Consumer(String id, String name, Integer unitConsumed) {
        this.id = id;
        this.name = name;
        this.unitConsumed = unitConsumed;
        this.finalPayment = BillService.billCalculation(this);
    }
    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public Integer getUnitConsumed() {
        return unitConsumed;
    }
    public String getFinalPayment() {
        return finalPayment;
    }
    @Override
    public String toString() {
        return String.format("%-5s %-20s %-10s %-10s", id, name, unitConsumed, finalPayment);
    }
}
