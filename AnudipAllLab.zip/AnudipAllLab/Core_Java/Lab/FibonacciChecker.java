package org.anudip.Lab;
import java.util.Scanner;
public class FibonacciChecker {
	 static boolean isPerfectSquare(int n) {
	        int sqrt = (int) Math.sqrt(n);
	        return sqrt * sqrt == n;
	    }
	    public static boolean isFibonacci(int n) {
	        return isPerfectSquare(5 * n * n + 4) || isPerfectSquare(5 * n * n - 4);
	    }
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        // Accept the input number
	        System.out.print("Enter the number: ");
	        int number = scanner.nextInt();
	        // Check if the number is part of the Fibonacci sequence
	        boolean isFibonacci = isFibonacci(number);
	        // Display the result
	        if (isFibonacci) {
	            System.out.println("yes");
	        } else {
	            System.out.println("no");
	        }
	    }
}
