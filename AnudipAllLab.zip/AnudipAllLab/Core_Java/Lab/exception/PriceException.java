package org.anudip.lab.exception;
public class PriceException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PriceException(String message) {
        super(message);
        }
}//end of class
