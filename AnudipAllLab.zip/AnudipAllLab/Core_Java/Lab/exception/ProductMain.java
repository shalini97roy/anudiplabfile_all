package org.anudip.lab.exception;
import java.util.Scanner;
public class ProductMain {
	public static void main(String[] args) {
		Scanner scanner =new Scanner(System.in);
		 //Accept the number of items
		 System.out.println("Enter the number of products: ");
		 int number=Integer.parseInt(scanner.nextLine());
		 //Create Product type Array
		 Product []productArr=new Product[number];
		 int length=productArr.length;
		 
		  //Accept all product details
		 System.out.println("Enter all products with their details in(id,name,purchasedPrice,salesPrice,grade):--");
		 for(int i=0; i<length;i++) {
			 System.out.println("Enter product "+(i+1)+":");
			 String product=scanner.nextLine();
			 String []arr=product.split(",");
			 int id=Integer.parseInt(arr[0]);
			 String name=arr[1];
			 double purchasedPrice=Double.parseDouble(arr[2]);
			 double salesPrice=Double.parseDouble(arr[3]);
			 String grade =arr[4];
			 String eCarry="E";
			 String nCarry="N";
			 Product products=new Product();
			 try {
			 //check,if sales price lower than purchase price then throw an exception
			 if(salesPrice<purchasedPrice) {
				 throw new PriceException("Sales price must be higher than purchase price");
			 }
			 //check,if the product grade is wrong then throw an exception
			 else if(!(grade.equals(eCarry)|| grade.equals(nCarry))) {
				 throw new GradeMismatchException("Wrong grade");
			 }
			 //check,if E graded product sales price is greater than 25% of purchase price then throw an exeption
			 else if(grade.equals(eCarry)&&(salesPrice>purchasedPrice+(0.25*purchasedPrice))) {
				 throw new EssentialCommodityException("E graded items sales price must be lesser than 25% of purchase price");
			 }
			 //set the all values of products
			 
				 products.setId(id);
				 products.setName(name);
				 products.setPurchasedPrice(purchasedPrice);
				 products.setSalesPrice(salesPrice);
				 products.setGrade(grade);
				 productArr[i]=products;
			 
		}//end of try
	     catch(PriceException pe) {
			 System.out.println("PriceException : "+pe.getMessage());
		 }//end of catch
       catch(EssentialCommodityException ece) {
      	 System.out.println("EssentialCommodityException : "+ece.getMessage());
       }//end of catch
		catch(GradeMismatchException ge) {
	        	 System.out.println("GradeMismatchException : "+ge.getMessage());
	    }//end of catch
		   
		 }//end loop
			    
		System.out.println(String.format("%-5s %-20s %-10s %-10s %-5s","id","name","CostPrice","salesPrice","grade"));
		
		//Display all products
		for(Product p:productArr) {
			if(p!=null) {
			System.out.println(p);
			}
		}
		System.out.println("The program is over");
		scanner.close();
	}//end of main

}//end of class