package org.anudip.lab.exception;
public class GradeMismatchException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GradeMismatchException(String message) {
        super(message);
    }
}//end of class