package org.anudip.Lab;
import java.util.Scanner;
public class IPAddressValidator {
	//verifying IP address is valid or not
	public static boolean isValidIP(String ipAddress) {
        String ipPattern = "^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$";
        return ipAddress.matches(ipPattern);
    }
public static void main(String[] args) {
		// TODO Auto-generated method stub
	//taking input from the user
	Scanner scanner = new Scanner(System.in);
    System.out.print("Enter an IP address: ");
    String ipAddress = scanner.nextLine();
  //display the input IP address is valid or not
    if (isValidIP(ipAddress)) {
        System.out.println(ipAddress + " is a valid IP address.");
    } else {
        System.out.println(ipAddress + " is NOT a valid IP address.");
    }
    scanner.close();
	}//end of main
}//end of class
