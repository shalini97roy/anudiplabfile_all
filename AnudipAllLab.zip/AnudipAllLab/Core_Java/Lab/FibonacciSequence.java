package org.anudip.Lab;
import java.util.Scanner;
public class FibonacciSequence {
	public static boolean isFibonacci(int n) {
        int first = 0;
        int second = 1;

        while (second < n) {
            int temp = second;
            second = first + second;
            first = temp;
        }

        if (second == n) {
            return true;
        } else {
            return false;
        }
    }

    public static void main(String[] args) {
        int numberToCheck = 8; // Change this value to test different numbers

        if (isFibonacci(numberToCheck)) {
            System.out.println(numberToCheck + " is part of the Fibonacci sequence.");
        } else {
            System.out.println(numberToCheck + " is not part of the Fibonacci sequence.");
        }
    }
}
