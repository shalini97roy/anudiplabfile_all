package org.anudip.lab.collection;
import java.util.Objects;
public class UnixUser {
	private Integer userId;
    private Integer employeeId;
    private String username;
    private String userType;
 // Constructor to initialize user details
    public UnixUser(Integer userId, Integer employeeId, String username, String userType) {
        this.userId = userId;
        this.employeeId = employeeId;
        this.username = username;
        this.userType = userType;
    }   
 // Getter for userId
    public Integer getUserId() {
        return userId;
    }
 // Getter for userId
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
 // Getter for employeeId
    public Integer getEmployeeId() {
        return employeeId;
    }
//Setter for employeeId
    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }
 // Getter for username
    public String getUsername() {
        return username;
    }
 // Setter for username
    public void setUsername(String username) {
        this.username = username;
    }
 // Getter for userType
    public String getUserType() {
        return userType;
    }
 // Setter for userType
    public void setUserType(String userType) {
        this.userType = userType;
    }
 // Override the toString() method to format user information
    @Override
    public String toString() {
    	return String.format("%-10s %-15s %-20s %-10s", userId, employeeId, username, userType);
    }
 // Override the hashCode() method to generate a hash code based on user details
    @Override
    public int hashCode() {
        return Objects.hash(userId, employeeId, username, userType);
    }
 // Override the equals() method to compare user objects for equality
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        UnixUser other = (UnixUser) obj;
        return Objects.equals(userId, other.userId) && Objects.equals(employeeId, other.employeeId)
                && Objects.equals(username, other.username) && Objects.equals(userType, other.userType);
    }
}