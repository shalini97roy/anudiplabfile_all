package org.anudip.lab;
import java.util.Scanner;
public class BillMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of consumers: ");
        int numConsumers = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character left by nextInt()
        if (numConsumers <= 0) {
            System.out.println("Invalid input.");
            extracted();
        }
        Consumer[] consumers = new Consumer[numConsumers];
        for (int i = 0; i < numConsumers; i++) {
            System.out.print("Enter details of consumer number " + (i + 1) + ": ");
            String input = scanner.nextLine();
            String[] details = input.split(",");
            String id = details[0].trim();
            String name = details[1].trim();
            int unitConsumed = Integer.parseInt(details[2].trim());
            consumers[i] = new Consumer(id, name, unitConsumed);
        }
        scanner.close();
        System.out.println("\nConsumer Details:");
        System.out.println(String.format("%-5s %-20s %-10s %-10s", "ID", "Name", "Unit", "Amount"));
        for (Consumer consumer : consumers) {
            System.out.println(consumer);
        }
    }
	private static void extracted() {
	}
}
