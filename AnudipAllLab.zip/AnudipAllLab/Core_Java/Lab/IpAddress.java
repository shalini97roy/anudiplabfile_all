package org.anudip.Lab;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class IpAddress {
	public static void main(String[] args) {
		try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter an Ip address:");
			String ip=scanner.nextLine();
			String regex = "((25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)\\.?\\b){4}$";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(ip);
			matcher.matches();
			if (matcher.matches()) 
			{
				System.out.println("valid");}
				else {
					System.out.println("Invalid");	
			                }
		}
	}
}