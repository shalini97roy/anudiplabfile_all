package org.anudip.hometask;
import java.util.Scanner;
public class ArraySumHighestLowest {
public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner scanner = new Scanner(System.in);
    // Accept the size of the array
    System.out.print("Enter the size of the array: ");
    int size = scanner.nextInt();
    // Check if the size is negative or less than 3
    if (size < 3) {
        System.out.println("Invalid Input. Size of the array should be at least 3.");
        scanner.close();
        return;
    }
    int[] arr = new int[size];
    // Accept input into the array and check for invalid inputs
    for (int i = 0; i < size; i++) {
        System.out.print("Enter element " + (i + 1) + ": ");
        arr[i] = scanner.nextInt();
        if (arr[i] <= 0) {
            System.out.println("Invalid Input. Inputs should be greater than 0.");
            scanner.close();
            return;
        }
    }
    scanner.close();
      // Find the sum of the highest and lowest inputs
    int highest = arr[0];
    int lowest = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] > highest) {
            highest = arr[i];
        }
        if (arr[i] < lowest) {
            lowest = arr[i];
        }
    }
int sum = highest + lowest;
    System.out.println("Sum of highest and lowest inputs: " + sum);
}
}
