package org.anudip.hometask;
import java.util.*;
public class CollectSingleCharacters {
public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner scanner = new Scanner(System.in);
    // Accept the input string
    System.out.print("Enter a string: ");
    String inputString = scanner.nextLine();
    scanner.close();
    // Collect single characters in ascending order
    String resultString = collectSingleCharacters(inputString);
    // Display the result
    System.out.println("Single characters in ascending order: " + resultString);
}
public static String collectSingleCharacters(String inputString) {
    Set<Character> singleCharacters = new TreeSet<>();
    for (char c : inputString.toCharArray()) {
        // Check if the character is a single character (non-repeating)
        if (inputString.indexOf(c) == inputString.lastIndexOf(c)) {
            singleCharacters.add(c);
        }
    }
    // Convert the Set to a string
    StringBuilder result = new StringBuilder();
    for (Character c : singleCharacters) {
        result.append(c);
    }
    return result.toString();
	}
}
