package org.anudip.hometask;
import java.util.Scanner;
public class ArraySumOfPrimes {
public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner scanner = new Scanner(System.in);
    // Accept the size of the array
    System.out.print("Enter the size of the array: ");
    int size = scanner.nextInt();
    // Check if the size is negative
    if (size < 0) {
        System.out.println("Invalid Input. Size of the array cannot be negative.");
        scanner.close();
        return;
    }
    int[] arr = new int[size];
    // Accept input into the array
    for (int i = 0; i < size; i++) {
        System.out.print("Enter element " + (i + 1) + ": ");
        arr[i] = scanner.nextInt();
    }
    scanner.close();
    // Find the sum of prime numbers in the array
    int sumOfPrimes = 0;
    boolean hasPrimes = false;    
    for (int num : arr) {
        if (isPrime(num)) {
            sumOfPrimes += num;
            hasPrimes = true;
        }
    }
    if (hasPrimes) {
        System.out.println("Sum of prime numbers: " + sumOfPrimes);
    } else {
        System.out.println("No prime number is present.");
    }
}
// Function to check if a number is prime
public static boolean isPrime(int number) {
    if (number <= 1) {
        return false;
    }
    for (int i = 2; i <= Math.sqrt(number); i++) {
        if (number % i == 0) {
            return false;
        }
    }
    return true;
	}
}
