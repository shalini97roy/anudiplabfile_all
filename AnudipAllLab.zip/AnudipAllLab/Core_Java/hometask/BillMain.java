package org.anudip.hometask;
import java.util.Scanner;

class Consumer {
    private String id;
    private String name;
    private Integer unitConsumed;
    private String finalPayment;

    public Consumer(String id, String name, Integer unitConsumed) {
        this.id = id;
        this.name = name;
        this.unitConsumed = unitConsumed;
        this.finalPayment = BillService.billCalculation(this);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Integer getUnitConsumed() {
        return unitConsumed;
    }

    public String getFinalPayment() {
        return finalPayment;
    }

    @Override
    public String toString() {
        return String.format("%-5s %-20s %-10s %-10s", id, name, unitConsumed, finalPayment);
    }
}

class BillService {
    public static String billCalculation(Consumer consumer) {
        int unitConsumed = consumer.getUnitConsumed();
        double finalPayment = 0.0;

        if (unitConsumed <= 200) {
            finalPayment = 300.0;
        } else if (unitConsumed <= 500) {
            finalPayment = 300.0 + (unitConsumed - 200) * 1.25;
        } else if (unitConsumed <= 1000) {
            finalPayment = 300.0 + 300.0 + (unitConsumed - 500) * 1.00;
        } else {
            finalPayment = 300.0 + 300.0 + 500.0 + (unitConsumed - 1000) * 0.75;
        }

        return String.format("%.2f", finalPayment);
    }
}

public class BillMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of consumers: ");
        int numConsumers = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character left by nextInt()

        if (numConsumers <= 0) {
            System.out.println("Invalid input.");
            return;
        }

        Consumer[] consumers = new Consumer[numConsumers];

        for (int i = 0; i < numConsumers; i++) {
            System.out.print("Enter details of consumer number " + (i + 1) + ": ");
            String input = scanner.nextLine();
            String[] details = input.split(",");

            String id = details[0].trim();
            String name = details[1].trim();
            int unitConsumed = Integer.parseInt(details[2].trim());

            consumers[i] = new Consumer(id, name, unitConsumed);
        }

        scanner.close();

        System.out.println("\nConsumer Details:");
        System.out.println(String.format("%-5s %-20s %-10s %-10s", "ID", "Name", "Unit", "Amount"));
        for (Consumer consumer : consumers) {
            System.out.println(consumer);
        }
    }
}
