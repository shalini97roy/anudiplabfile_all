package org.anudip.hometask;
public class Main {
public static void main(String[] args) {
		// TODO Auto-generated method stub
    String myString = "venkataraghavan";
    int cutPoint = 6;
    int numbersOfCharacters = 5;

    String extractedSubString = extractSubString(myString, cutPoint, numbersOfCharacters);
    System.out.println("Extracted Substring: " + extractedSubString);
}
public static String extractSubString(String myString, int cutPoint, int numbersOfCharacters) {
    if (cutPoint < 0 || cutPoint >= myString.length()) {
        throw new IllegalArgumentException("Invalid cutPoint. It should be between 0 and " + (myString.length() - 1));
    }

    if (numbersOfCharacters <= 0) {
        throw new IllegalArgumentException("Number of characters should be greater than 0.");
    }

    int endIndex = Math.min(cutPoint + numbersOfCharacters, myString.length());
    return myString.substring(cutPoint, endIndex);
}

	}