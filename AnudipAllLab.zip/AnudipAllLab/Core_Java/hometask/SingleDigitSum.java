package org.anudip.hometask;
import java.util.Scanner;
public class SingleDigitSum {
public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number with at least 10 digits: ");
        String input = scanner.nextLine();
        scanner.close();
       long number;
        try {
            number = Long.parseLong(input);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid number with at least 10 digits.");
            return;
        }
       if (input.length() < 10) {
            System.out.println("Invalid input. Please enter a number with at least 10 digits.");
            return;
        }
       int result = calculateSingleDigitSum(number);
        System.out.println("Single-digit output: " + result);
    }
  public static int calculateSingleDigitSum(long number) {
        int sum = 0;
        while (number != 0) {
            sum += number % 10;
            number /= 10;
        }
      if (sum >= 10) {
            return calculateSingleDigitSum(sum);
        }
        return sum;
    }
	    }
