package org.anudip.hibernateLab.application;
import org.anudip.hibernateLab.bean.Product;
import org.anudip.hibernateLab.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.Scanner;
public class ProductEntry {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of products: ");
        int numProducts = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        String[] productStrings = new String[numProducts];
        for (int i = 0; i < numProducts; i++) {
            System.out.print("Enter product details (e.g., productId,productName,purchasedPrice,salesPrice,grade): ");
            productStrings[i] = scanner.nextLine();
        }

        scanner.close();

        DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
        Session session = null;
        Transaction tx = null;

        try {
            session = dbHandler.createSession();
            tx = session.beginTransaction();

            for (String productStr : productStrings) {
                String[] parts = productStr.split(",");
                Integer productId = Integer.parseInt(parts[0]);
                String productName = parts[1];
                Double purchasedPrice = Double.parseDouble(parts[2]);
                Double salesPrice = Double.parseDouble(parts[3]);
                String grade = parts[4];

                // Create Product object
                Product product = new Product(productId, productName, purchasedPrice, salesPrice, grade);
                session.save(product);
            }
            tx.commit();
            System.out.println("Products added to the database successfully.");
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                dbHandler.closeSession(session);
            }
        }
    }
}