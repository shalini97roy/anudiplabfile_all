package org.anudip.hibernateLab.application;

import org.anudip.hibernateLab.bean.Product;
import org.anudip.hibernateLab.dao.DatabaseHandler;
import org.hibernate.Session;

import java.util.List;

public class ProductShow {
    public static void main(String[] args) {
        DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
        Session session = null;

        try {
            session = dbHandler.createSession();

            // Retrieve and display products
            List<Product> products = session.createQuery("from Product", Product.class).list();
            System.out.println("Product List:");
            for (Product product : products) {
                System.out.println(product);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (session != null) {
                dbHandler.closeSession(session);
            }
        }
    }
}