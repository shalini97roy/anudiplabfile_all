package org.anudip.labHibernate.bean;
//Custom exception class for essential commodity exceptions
public class EssentialCommodityException extends RuntimeException {	
	// Constructor for EssentialCommodityException class that accepts a message
  public EssentialCommodityException(String message) {
  	// Call the constructor of the parent class (RuntimeException) with the provided message
      super(message);    }
}
