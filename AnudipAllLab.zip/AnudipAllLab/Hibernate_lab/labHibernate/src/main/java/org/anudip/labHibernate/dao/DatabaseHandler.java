package org.anudip.labHibernate.dao;
import java.io.IOException;
import java.util.Properties;
import org.anudip.labHibernate.bean.Product;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class DatabaseHandler {
	 private static final DatabaseHandler dbHandler = new DatabaseHandler();
	    private DatabaseHandler() {}
	 // Get the single instance of DatabaseHandler
	    public static DatabaseHandler getDatabaseHandler() {
	        return dbHandler;
	    }
	    // Create a Hibernate session
	    public Session createSession() throws IOException {
	        // Load Hibernate properties from hibernate.properties
	        Properties properties = new Properties();
	        properties.load(DatabaseHandler.class.getClassLoader().getResourceAsStream("hibernate.properties"));
	        // Create a Hibernate configuration
	        Configuration config = new Configuration();
	        config.setProperties(properties);
	        config.addAnnotatedClass(Product.class); // Mention your entity class
	        // Build the SessionFactory
	        SessionFactory factory = config.buildSessionFactory();
	        // Open a Hibernate session
	        Session session = factory.openSession();
	        return session;
	    }
	    // Close a Hibernate session
	    public void closeSession(Session session) {
	        if (session != null) {
	            session.close();
	        }
	    }    
	 // Close a Hibernate SessionFactory
	    public void closeSessionFactory(SessionFactory factory) {
	        if (factory != null) {
	            factory.close();
	        }
	    }
	}