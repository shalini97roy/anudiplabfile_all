package org.anudip.HibernateLab2.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "result") // Entity representing the "result" table
public class Result {
    @Id
    @Column(name = "roll_number") // Column for Roll Number
    private String rollNumber;
    @Column(name = "half_yearly_total") // Column for Half Yearly Total
    private Double halfYearlyTotal;
    @Column(name = "annual_total") // Column for Annual Total
    private Double annualTotal;
    @Column(name = "grade") // Column for Grade
    private String grade;
    // Constructors
    public Result() {
        // Default constructor required by Hibernate
    }
    public Result(String rollNumber, Double halfYearlyTotal, Double annualTotal) {
        this.rollNumber = rollNumber;
        this.halfYearlyTotal = halfYearlyTotal;
        this.annualTotal = annualTotal;
        this.grade = gradeCalculation(annualTotal + halfYearlyTotal);
    }
    // Getter method for rollNumber
    public String getRollNumber() {
        return rollNumber;
    }
    // Setter method for rollNumber
    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }
    // Getter method for halfYearlyTotal
    public Double getHalfYearlyTotal() {
        return halfYearlyTotal;
    }
    // Setter method for halfYearlyTotal
    public void setHalfYearlyTotal(Double halfYearlyTotal) {
        this.halfYearlyTotal = halfYearlyTotal;
    }
    // Getter method for annualTotal
    public Double getAnnualTotal() {
        return annualTotal;
    }
    // Setter method for annualTotal
    public void setAnnualTotal(Double annualTotal) {
        this.annualTotal = annualTotal;
    }
    // Getter method for grade
    public String getGrade() {
        return grade;
    }
    // You can add other methods as needed
    @Override
    public String toString() {
        return String.format("%-5s %-20s %-20s  %-5s", rollNumber, halfYearlyTotal, annualTotal, grade);
    }
    private String gradeCalculation(double totalMarks) {
        if (totalMarks >= 90) {
            return "E";
        } else if (totalMarks >= 75) {
            return "V";
        } else if (totalMarks >= 60) {
            return "G";
        } else if (totalMarks >= 45) {
            return "P";
        } else {
            return "F";
        }
    }
}
