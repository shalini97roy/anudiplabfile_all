package org.anudip.HibernateLab2.bean;
// Custom exception class for student not found
public class StudentNotFoundException extends RuntimeException {
    static final long serialVersionUID = 1L;
    // Constructor with a message parameter
    public StudentNotFoundException(String message)
    {
        super(message);
    }
}
