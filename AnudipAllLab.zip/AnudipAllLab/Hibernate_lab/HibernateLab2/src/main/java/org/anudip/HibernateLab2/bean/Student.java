package org.anudip.HibernateLab2.bean;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name = "Student") // Entity representing the "Student" table
public class Student {
    @Id
    @Column(name = "Roll_Number") // Column for Student's Roll Number
    private String rollNumber;
    @Column(name = "Student_Name") // Column for Student's Name
    private String studentName;
    @Column(name = "Semester") // Column for Student's Semester
    private String semester;
    @OneToOne(fetch = FetchType.LAZY, targetEntity = Result.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "Roll_Number") // Join column related to Roll Number
    private Result studentResult; // Entity association with the "Result" class
    // Add a field for halfYearlyTotal
    @Column(name = "Half_Yearly_Total") // Column for Student's Half Yearly Total
    private double halfYearlyTotal;
    public Student() {
        super();
    }
    // Update the constructor to accept halfYearlyTotal
    public Student(String rollNumber, String studentName, String semester, double halfYearlyTotal) {
        super();
        this.rollNumber = rollNumber;
        this.studentName = studentName;
        this.semester = semester;
        this.halfYearlyTotal = halfYearlyTotal;
    }
    public String getRollNumber() {
        return rollNumber;
    }
    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }
    public String getStudentName() {
        return studentName;
    }
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    public String getSemester() {
        return semester;
    }
    public void setSemester(String semester) {
        this.semester = semester;
    }
    public Result getStudentResult() {
        return studentResult;
    }
    public void setStudentResult(Result studentResult) {
        this.studentResult = studentResult;
    }
    public double getHalfYearlyTotal() {
        return halfYearlyTotal;
    }
    public void setHalfYearlyTotal(double halfYearlyTotal) {
        this.halfYearlyTotal = halfYearlyTotal;
    }
    @Override
    public String toString() {
        return String.format("%-5s %-20s %-5s %-2s", rollNumber, studentName, semester, studentResult);
    }
}
