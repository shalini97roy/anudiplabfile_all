package org.anudip.HibernateLab2.bean;
public class ResultService {
    // Method to calculate the grade based on the given formula
    public static String gradeCalculation(Result result) {
        // Calculate the grade based on the given formula
        double totalScore = result.getHalfYearlyTotal() + result.getAnnualTotal();
        double percentage = (totalScore / 1000) * 100;
        if (percentage >= 90) {
            return "E"; // E grade
        } else if (percentage >= 75) {
            return "V"; // V grade
        } else if (percentage >= 60) {
            return "G"; // G grade
        } else if (percentage >= 45) {
            return "P"; // P grade
        } else {
            return "F"; // F grade
        }
    }
}
