package org.lab.thread;
public class StudentResult {
	 private String rollNumber;
	    private String studentName;
	    private double halfYearlyTotal;
	    private double annualTotal;
	    private String grade;
	    public StudentResult(String rollNumber, String studentName, double halfYearlyTotal) {
	        this.rollNumber = rollNumber;
	        this.studentName = studentName;
	        this.halfYearlyTotal = halfYearlyTotal;
	    }
	    public String getRollNumber() {
	        return rollNumber;
	    }
	    public String getStudentName() {
	        return studentName;
	    }
	    public double getHalfYearlyTotal() {
	        return halfYearlyTotal;
	    }
	    public double getAnnualTotal() {
	        return annualTotal;
	    }
	    public void setAnnualTotal(double annualTotal) {
	        this.annualTotal = annualTotal;
	    }
	    public String getGrade() {
	        return grade;
	    }
	    public void setGrade(String grade) {
	        this.grade = grade;
	    }
	    @Override
	    public String toString() {
	        return rollNumber + " - " + studentName + " - " + annualTotal + " - " + grade;
	    }
	}